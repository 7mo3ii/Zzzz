import requests,json,random


class tempmail:
    url = "https://api.mail.tm"
    
    def get_domain(self):
        domains = requests.get(self.url+"/domains").json()
        if domains["hydra:member"]:
            return domains["hydra:member"][0]["domain"]
        else:
            return None

    def get_email_address(self):
        domain = self.get_domain()
        name = self.get_arab_name()
        if domain:
            return name+self.get_rand_int(4)+self.get_rand_str(1)+"@"+domain
        else:
            return None

    def create_email_address(self,address):
        data = {"address":address,"password":"stormghosts$123"}
        self.account = requests.post(self.url+"/accounts",json=data).json()
        self.token = requests.post(self.url+"/token",json=data).json()["token"]
        self.headers = {"Authorization":"Bearer "+self.token}
        return True


    def set_email_address(self,address):
        data = {"address":address,"password":"stormghosts$123"}
        self.token = requests.post(self.url+"/token",json=data).json()["token"]
        self.headers = {"Authorization":"Bearer "+self.token}
        return True


    def get_messages(self):
        return requests.get(self.url+"/messages?page=1",headers=self.headers).json()["hydra:member"]
        
        
    def get_message_data(self, id):
        return requests.get(self.url+f"/messages/{id}",headers=self.headers).json()
        

    def get_rand_str(self,count):
        return ''.join(random.choice("qwertyuiopasdfghjklzxcvbnm") for x in range(int(count)))

    def get_rand_int(self,count):
        return ''.join(random.choice("1234567890") for x in range(int(count)))

    def get_arab_name(self):
        names = ["hany", "eng", "maha", "eman", "sameh", "atif", "sulaiman", "mahdi", "shahid", "akram", "hanan", "fayez", "manal", "hazem", "zuhair", "hosam", "nabeel", "haytham", "salim", "esam", "kareem", "taher", "nadia", "firas", "heba", "nadeem", "ghada", "maryam", "hala", "noura", "sahar", "ziyad", "tahir", "sajid", "ramy", "jehad", "amro", "jihad", "marwa", "medhat", "nasir", "tareq", "atef", "wesam", "amani", "mazin", "fawzi", "taha", "imam", "mustafa", "samar", "gamal", "naveed", "mohsin", "ghassan", "khalil", "saif", "saleem", "areej", "asma", "dina", "faiz", "arshad", "zahra", "nidal", "fathi", "ihab", "rana", "abdulmohsen", "naji", "maram", "shady", "ahmed", "lolo", "waseem", "azhar", "hind", "mutaz", "muhammed", "magdy", "ehsan", "kamran", "noha", "ramzi", "nouf", "adeeb", "bahaa", "hamdi", "raja", "ebrahim", "haifa", "naeem", "sohail", "aly", "abdulhadi", "qasim", "ahmad", "salwa", "rasha", "najeeb", "abrar", "abdelrahman", "asim", "malik", "hasan", "ali", "imad", "mamdouh", "moataz", "obaid", "magdi", "bassem", "rashed", "muneer", "rehab", "javed", "mohmed", "abid", "asad", "kashif", "afnan", "fatima", "murad", "zaher", "reham", "sadiq", "rania", "osamah", "basheer", "shoaib", "hattan", "abdel", "anis", "khaja", "tahani", "doaa", "abubaker", "abdalla", "loay", "jameel", "wafaa", "nawal", "muath", "mai", "moustafa", "iyad", "abdulhameed", "jassim", "rashad", "nour", "dalal", "hamzah", "ola", "haris", "shaker", "musab", "aamir", "dawood", "nasr", "ayed", "sawsan", "fahed", "majdi", "arwa", "iman", "abdulah", "haya", "shakeel", "wafa", "sajjad", "wassim", "razan", "waqas", "abdulraheem", "muhamad", "moath", "safwan", "siraj", "saber", "diaa", "zeeshan", "syed", "hafiz", "ismail", "jawad", "zeyad", "nisar", "mohamed", "ruba", "soliman", "mujtaba", "tawfiq", "suhail", "zaki", "abdullah", "isam", "junaid", "basel", "ala'a", "abdulrahim", "moayad", "nezar", "rizwan", "hadeel", "ameen", "lamia", "raid", "mohamd", "hazim", "fadel", "wasim", "fuad", "hilal", "yassir", "zainab", "khaleel", "rehan", "ahsan"]
        return random.choice(names)









