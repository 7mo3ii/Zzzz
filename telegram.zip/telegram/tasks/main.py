from telethon.tl.functions.channels import *
from telethon.tl.functions.channels import CreateChannelRequest, UpdateUsernameRequest
from telethon.tl.types import *
from telethon import *
from telethon.tl.functions.contacts import ResolveUsernameRequest
from telethon.errors import *
import asyncio, telethon, time, string, threading, telebot, requests, sys, json, random, datetime
from telethon.tl.functions.messages import *
from telethon.tl.functions.account import *
from telethon.sessions import StringSession
from telethon.tl.functions.photos import UploadProfilePhotoRequest
from lsedb import *
from telebot.types import *
from telebot.apihelper import *
import datetime,re,urllib, names
from bs4 import BeautifulSoup
from user_agent import generate_user_agent
from tempmail import *


bot = telebot.TeleBot("6211449581:AAEQNgSbd5tein_cjGF_Y4ikoFz7gSWrARI")
dev_id = "1502342753"
dev_user = "A_5_5_B"
serverdb = lsedb("lse","mahmoud123","telegram","server")
usersdb = lsedb("lse","mahmoud123","telegram","users")
tasksdb = lsedb("lse","mahmoud123","telegram","tasks")
pricesdb = lsedb("lse","mahmoud123","telegram","prices")
sessionsdb = lsedb("lse","mahmoud123","billion","sessions")
server = None
users = None
tasks = None
prices = None
sessions = None
session = 0





def getSessions():
    global sessionsdb, sessions
    sessions0 = sessionsdb.get()["msg"]
    sessions = []
    dt = int(round(datetime.datetime.now().timestamp()))
    for s in range(len(sessions0)):
      if not "running" in sessions0[s]:
        sessions0[s]["running"] = False
      if not sessions0[s]["main"] and not sessions0[s]["running"] and not "max" in sessions0[s] and "session" in sessions0[s]:
        if "flood" in sessions0[s]:
            if dt > int(sessions0[s]["flood"]):
                sessions.append(sessions0[s])
                sessions0[s].pop("flood")
                sessionsdb.edit(sessions0[s])
        else:
            sessions.append(sessions0[s])
    sessions = sorted(sessions, key=lambda x: x['phone'])
    return sessions
    








async def main(session0):
  global sessions, serverdb, usersdb, tasksdb
  global sessionsdb, pricesdb, server, users, tasks, prices,bot
  session = session0
  if session >= len(sessions):
    session = 0
  phone = sessions[session]["phone"]
  api_id = sessions[session]["api_id"]
  api_hash = sessions[session]["api_hash"]
  if "session" in sessions[session]:
    a = sessions[session]["session"]
  else:
    a = ""
  print(f"Connected To : {phone}")
  print(f"{session}/{len(sessions)}")
  try:
    client = TelegramClient(StringSession(a), api_id, api_hash)
    await client.connect()
    s = (await client.is_user_authorized())
  except Exception as e:
    s = False
    print(e)
  if await client.is_user_authorized():
    try:
      client.parse_mode = "markdown"
      os.system("clear")
      print(f"Session : {session}")
      print(f"Connected To : {phone}")
      my_user = await client.get_me()
      my_id = my_user.id
      print("Script Started Successfully ... In " + str(my_id))
      d = random.choice([True,False])
      print("check Acoount Name ..!")
      if not str(my_user.first_name) in get_arab_name(getList=True):
          print("Change Account Name ...")
          await client(telethon.tl.functions.account.UpdateProfileRequest(first_name=get_arab_name(d),last_name=get_arab_name(d)))
      print("Check UserName ..!")
      if not my_user.username:
          print("Set UserName ...")
          na = str(get_arab_name()).lower().strip()+get_rand(5)
          await client(telethon.tl.functions.account.UpdateUsernameRequest(na))
      print("Check Premium Link ...")
      telegram = await client.get_input_entity(777000)
      async for message in client.iter_messages(telegram, wait_time=3, limit=5):
          try:
            link = "https://t.me/giftcode/" + str(message.action.slug)
            msg = """
- تم إيجاد رابط مميز 🌟
  المدة : {} شهر
  الرابط : {}
"""
            await client.send_message(dev_id,msg.format(str(message.action.months),link))
          except:
            if "Request to reset password" in message.text or "حذف" message.text:
                users = usersdb.get()["msg"]
                for u in users:
                    if sessions[session]["phone"] in u["phones"]:
                        u["ban"] = 1
                        usersdb.edit(u)
                        bot.send_message(chat_id=u["uid"],text=f"- تم حظر حسابك لانك قمت بطلب حذف الرقم {sessions[session]['phone']} .")
                        break
                
      print("Check Sessions ...")
      dt = int(round(datetime.now().timestamp()))
      if "create" in sessions[session]:
          if (dt - sessions[session]["create"]) >= 86500:
              result = (await client(telethon.tl.functions.account.GetAuthorizationsRequest())).authorizations
              done = False
              if len(result) > 1:
                  print("sessions reset ...")
                  try:
                      await client(telethon.tl.functions.auth.ResetAuthorizationsRequest())
                      done = True
                  except Exception as e:
                      if "is new" in str(e):
                          done = False
              if len(result) == 1 or done:
                  print("Check Is Points Taken ...")
                  prices = pricesdb.get()["msg"]
                  users = usersdb.get()["msg"]
                  if not "points" in sessions[session]:
                      for u in users:
                          if sessions[session]["phone"] in u["phones"]:
                              for p in prices:
                                  if p["code"] in sessions[session]["phone"]:
                                      u["points"] += p["points"]
                                      usersdb.edit(u)
                                      sessions[session]["points"] = p["points"]
                                      sessionsdb.edit(sessions[session])
                                      bot.send_message(chat_id=u["uid"],text=f"- تم إضافة {p['points']} نقاط لحسابك مقابل الرقم {sessions[session]['phone']} .")
                                      print(f"User {u['uid']} Take {p['points']} Points .")
                                      break
                              break
              
      print(f"{session+1}/{len(sessions)}")
      user = None
      for task in tasks:
        try:
          server = serverdb.get()["msg"][0]
          users = usersdb.get()["msg"]
          for u in users:
              if str(u["uid"]) == str(task["user"]):
                  user = u
                  break
          if task["action"] == "votes":
              msg_id = task["link"].split("/")[-1]
              link = task["link"].replace(msg_id,"")[:-1]
              channel = filterurl(link, getlast=True)
              target = await client.get_entity(channel)
              await asyncio.sleep(2)
              if isinstance(target, telethon.tl.types.Channel):
                  await asyncio.sleep(3)
                  print(f"getting message by {msg_id}")
                  # get message by msg_id
                  message = await client.get_messages(target, ids=int(msg_id))
                  if message and message. buttons:
                      # join channel
                      print(f"join channel {channel}")
                      await asyncio.sleep(2)
                      await client(JoinChannelRequest(target))
                      await asyncio.sleep(2)
                      while True:
                        # click like button
                        print("click like button")
                        m = (await message.click(0)).message
                        time.sleep(3)
                        print(m)
                        if "this." in str(m) or "تم التصويت" in str(m):
                          task["current"] += 1
                          if int(task["current"]) >= int(task["votes"]):
                              task["status"] = 1
                          if not "msg_id" in task:
                              msg_id0 = bot.send_message(task["user"], "جارى تنفيذ طلبك, رسالة من السيرفر ☑️").id
                              task["msg_id"] = msg_id0
                          tasksdb.edit(task)
                          msg = """
* - جارى إضافة تصويتات* ☑️

*~> المنشور *: [{}]({})
*~> التصويتات الكلية *: {} تصويت
*~> التصويتات الحالية *: {} تصويت
*~> النقاط المخصومه *: {} نقطة
*~> حالة طلبك *: {}
*~> معرف طلبك *: `{}`

<+> الرجاء عدم حذف هذه الرسالة الا عند الانتهاء, لأنه يتم تعديلها تلقائيا .
    """
                          if int(task["current"]) >= int(task["votes"]):
                              status = "اكتمل طلبك"
                          else:
                              status = "جارى التنفيذ"
                          msg = msg.format(task["link"],task["link"],task["votes"],task["current"],task["points"],status,task["key"])
                          bot.edit_message_text(chat_id=task["user"],text=msg,message_id=task["msg_id"],parse_mode="markdown", disable_web_page_preview=True)
                          break
                      
                  else:
                      # post not found
                      print("post not found")
                      task["status"] = 2
                      task["error"] = "post not found"
                      tasksdb.edit(task)
                      user["points"] += int(task["points"])
                      usersdb.edit(user)
                      msg = f"- عزيزى المستخدم لم يتم تنفيذ طلبك, و السبب لأنه لم يتم إيجاد المنشور, تأكد من إدخال رابط صحيح, تم الغاء طلبك و إرجاع {task['points']} نقاط ."
                      bot.send_message(task["user"],msg)
              else:
                  # link not channel
                  print("link not found")
                  task["status"] = 2
                  task["error"] = "link not channel"
                  tasksdb.edit(task)
                  user["points"] += int(task["points"])
                  usersdb.edit(user)
                  msg = f"- عزيزى المستخدم لم يتم تنفيذ طلبك, و السبب لأن الرابط لا ينتمى إلى قناة, تأكد من إدخال رابط قناة وليس مجموعة, تم الغاء طلبك و إرجاع {task['points']} نقاط ."
                  bot.send_message(task["user"],msg)
              await asyncio.sleep(1)
              
          elif task["action"] == "bot_referrals":
              task["status"] = 2
              task["error"] = "bot_referrals not ready"
              tasksdb.edit(task)
              user["points"] += int(task["points"])
              usersdb.edit(user)
              msg = f"- عزيزى المستخدم لم يتم تنفيذ طلبك, و السبب لأن هذة الخدمة فى صيانة, تم الغاء طلبك و إرجاع {task['points']} نقاط ."
              bot.send_message(task["user"],msg)
          elif task["action"] == "reacts":
              msg_id = task["link"].split("/")[-1]
              link = task["link"].replace(msg_id,"")[:-1]
              channel = filterurl(link, getlast=True)
              target = await client.get_entity(channel)
              await asyncio.sleep(2)
              print(f"getting message by {msg_id}")
              # get message by msg_id
              message = await client.get_messages(target, ids=int(msg_id))
              if message:
                await asyncio.sleep(3)
                # send react
                while True:
                  try:
                    react = ["❤️","👍","🔥","🥰","🤩","🤡","🎉","👌","😍","⚡"]
                    reac = random.choice(react)
                    print("sending react ... "+reac)
                    await client(telethon.tl.functions.messages.SendReactionRequest(peer=message.to_id,msg_id=int(msg_id),reaction=[telethon.tl.types.ReactionEmoji(emoticon=str(reac))]))
                    await asyncio.sleep(3)
                    break
                  except Exception:
                    await asyncio.sleep(3)
                task["current"] += 1
                if int(task["current"]) >= int(task["reacts"]):
                    task["status"] = 1
                if not "msg_id" in task:
                    msg_id0 = bot.send_message(task["user"], "جارى تنفيذ طلبك, رسالة من السيرفر ☑️").id
                    task["msg_id"] = msg_id0
                tasksdb.edit(task)
                msg = """
* - جارى إضافة تفاعلات* ☑️

*~> المنشور *: [{}]({})
*~> التفاعلات الكلية *: {} تفاعل
*~> التفاعلات الحالية *: {} تفاعل
*~> النقاط المخصومه *: {} نقطة
*~> حالة طلبك *: {}
*~> معرف طلبك *: `{}`

<+> الرجاء عدم حذف هذه الرسالة الا عند الانتهاء, لأنه يتم تعديلها تلقائيا .
"""
                if int(task["current"]) >= int(task["reacts"]):
                    status = "اكتمل طلبك"
                else:
                    status = "جارى التنفيذ"
                msg = msg.format(task["link"],task["link"],task["reacts"],task["current"],task["points"],status,task["key"])
                bot.edit_message_text(chat_id=task["user"],text=msg,message_id=task["msg_id"],parse_mode="markdown", disable_web_page_preview=True)
                  
              else:
                  # post not found
                  print("post not found")
                  task["status"] = 2
                  task["error"] = "post not found"
                  tasksdb.edit(task)
                  user["points"] += int(task["points"])
                  usersdb.edit(user)
                  msg = f"- عزيزى المستخدم لم يتم تنفيذ طلبك, و السبب لأنه لم يتم إيجاد المنشور, تأكد من إدخال رابط صحيح, تم الغاء طلبك و إرجاع {task['points']} نقاط ."
                  bot.send_message(task["user"],msg)
              await asyncio.sleep(1)
        except Exception as e:
          print(e)
          await asyncio.sleep(5)
      
      await client.disconnect()
    except FloodWaitError as e:
      print("flood")
      sessions[session]["flood"] = int(round(datetime.now().timestamp())) + int(e.seconds)
      sessionsdb.edit(sessions[session])
      await client.disconnect()
    except ChannelsTooMuchError:
      print("channels max")
      await client.disconnect()
    except AuthKeyDuplicatedError:
      print("session end")
      sessionsdb.delete(sessions[session])
      await client.disconnect()
    except UserDeactivatedBanError:
      print("account deleted")
      users = usersdb.get()["msg"]
      for u in users:
        if sessions[session]["phone"] in u["phones"]:
            u["ban"] = 1
            usersdb.edit(u)
            bot.send_message(chat_id=u["uid"],text=f"- تم حظر حسابك لانك قمت بحذف الرقم {sessions[session]['phone']} .")
            break
      sessionsdb.delete(sessions[session])
      await client.disconnect()
    except AuthKeyUnregisteredError:
      print("session end")
      sessionsdb.delete(sessions[session])
      await client.disconnect()
    except Exception as e:
      print(e)
    last_time = int(round(datetime.datetime.now().timestamp()))
    await asyncio.sleep(6)
  else:
    print("faild auth")
    users = usersdb.get()["msg"]
    for u in users:
        if sessions[session]["phone"] in u["phones"]:
            u["ban"] = 1
            usersdb.edit(u)
            bot.send_message(chat_id=u["uid"],text=f"- تم حظر حسابك لانك قمت بطرد الجلسة من الرقم {sessions[session]['phone']} .")
            break
    sessionsdb.delete(sessions[session])


#        await client.run_until_disconnected()


def get_rand(count):
  return ''.join(random.choice("qwertyuiopasdfghjklzxcvbnm1234567890")for x in range(int(count)))


def get_rand_str(count):
  return ''.join(random.choice("qwertyuiopasdfghjklzxcvbnm") for x in range(int(count)))


def get_rand_int(count):
  return ''.join(random.choice("1234567890") for x in range(int(count)))


async def follow(client, channel):
  try:
    channel = filterurl(channel, getlast=True)
    channel = await client.get_entity(channel)
    if isinstance(channel, telethon.tl.types.Channel):
      return await client(JoinChannelRequest(channel))
    else:
      return await client(ImportChatInviteRequest(hash=channel))
  except FloodWaitError as e:
    time.sleep(10)
    await client.disconnect()
    return None
  except ValueError:
    try:
      return await client(ImportChatInviteRequest(hash=channel))
    except UserAlreadyParticipantError:
      return True
    except Exception as e:
        return None
  except ChannelsTooMuchError:
    return None
  except UserAlreadyParticipantError:
    return True
  except Exception as e:
      return None


def filterurl(url, end=" ", getlast=False):
  link = str(url)
  if int(link.find("http")) > -1:
    link = link[link.find("http"):]
  if int(link.find(end)) > -1:
    link = link[0:link.find(end)]
  link = link.replace(" ", "")
  if getlast:
    link = link.split("/")
    link = link[len(link) - 1]
  link = link.replace("+", "")
  link = link.replace("*", "")
  return link.strip()






def sort_tasks():
    global tasks
    tasks0 = []
    for task in tasks:
        if task["action"] == "votes":
            task["sort"] = 1
        elif task["action"] == "bot_referrals":
            task["sort"] = 2
        else:
            task["sort"] = 3
        tasks0.append(task)
    tasks0 = sorted(tasks0, key=lambda x: x['sort'])
    return tasks0






def get_task(link,key):
    global tasks0
    i = 0
    for task in tasks0:
        if link == task["link"] and not key == task["key"]:
            i += task["current"]
    return i







def get_arab_name(arabic=False,getList=False):
    names = ["hany", "eng", "maha", "eman", "sameh", "atif", "sulaiman", "mahdi", "shahid", "akram", "hanan", "fayez", "manal", "hazem", "zuhair", "hosam", "nabeel", "haytham", "salim", "esam", "kareem", "taher", "nadia", "firas", "heba", "nadeem", "ghada", "maryam", "hala", "noura", "sahar", "ziyad", "tahir", "sajid", "ramy", "jehad", "amro", "jihad", "marwa", "medhat", "nasir", "tareq", "atef", "wesam", "amani", "mazin", "fawzi", "taha", "imam", "mustafa", "samar", "gamal", "naveed", "mohsin", "ghassan", "khalil", "saif", "saleem", "areej", "asma", "dina", "faiz", "arshad", "zahra", "nidal", "fathi", "ihab", "rana", "abdulmohsen", "naji", "maram", "shady", "ahmed", "lolo", "waseem", "azhar", "hind", "mutaz", "muhammed", "magdy", "ehsan", "kamran", "noha", "ramzi", "nouf", "adeeb", "bahaa", "hamdi", "raja", "ebrahim", "haifa", "naeem", "sohail", "aly", "abdulhadi", "qasim", "ahmad", "salwa", "rasha", "najeeb", "abrar", "abdelrahman", "asim", "malik", "hasan", "ali", "imad", "mamdouh", "moataz", "obaid", "magdi", "bassem", "rashed", "muneer", "rehab", "javed", "mohmed", "abid", "asad", "kashif", "afnan", "fatima", "murad", "zaher", "reham", "sadiq", "rania", "osamah", "basheer", "shoaib", "hattan", "abdel", "anis", "khaja", "tahani", "doaa", "abubaker", "abdalla", "loay", "jameel", "wafaa", "nawal", "muath", "mai", "moustafa", "iyad", "abdulhameed", "jassim", "rashad", "nour", "dalal", "hamzah", "ola", "haris", "shaker", "musab", "aamir", "dawood", "nasr", "ayed", "sawsan", "fahed", "majdi", "arwa", "iman", "abdulah", "haya", "shakeel", "wafa", "sajjad", "wassim", "razan", "waqas", "abdulraheem", "muhamad", "moath", "safwan", "siraj", "saber", "diaa", "zeeshan", "syed", "hafiz", "ismail", "jawad", "zeyad", "nisar", "mohamed", "ruba", "soliman", "mujtaba", "tawfiq", "suhail", "zaki", "abdullah", "isam", "junaid", "basel", "ala'a", "abdulrahim", "moayad", "nezar", "rizwan", "hadeel", "ameen", "lamia", "raid", "mohamd", "hazim", "fadel", "wasim", "fuad", "hilal", "yassir", "zainab", "khaleel", "rehan", "ahsan"]
    names0 = ["مسعد", "شيار", "ميرزا", "مجتبى", "عزام", "اصيل", "عبد الرؤوف", "سالم", "أسماعيل", "رامي", "جسور", "جاسر", "يحيى", "يزيد", "سليم", "آزاد", "سيف", "أوس", "اياد", "مُهاب", "سعود", "فيصل", "سامي", "سراج الدين", "ماركو", "مؤيد", "عمرو", "معتصم", "باسم", "مصطفى", "اسلام", "عمر", "مازن", "زياد", "روناء", "هيثم", "ياسين", "أمين", "أدهم", "براء", "مالك", "حمزة", "اياس", "يزن", "ايتن", "أمير", "أكمل", "أشرف", "أسعد", "أدريس", "اسِر", "صَفِيُّ", "سعد", "عبدالرحمن", "تميم", "ياسر", "طارق", "علي", "إدريس", "أحمد", "إحسان", "كريم", "ساري", "دريد", "خليل", "خالد", "سامر", "جاسم", "جعفر", "جمال", "جلال", "جبر", "بلال", "أيمن", "أيوب", "أسامة", "أكرم", "صهيب", "شاهين", "زيدون", "رامز", "راشد", "داود", "خلدون", "حسان", "جواد", "تيم", "نيار", "إلياس", "إبراهيم", "وائل", "يامن", "أيهم", "فادي", "مجدي", "وسيم", "بسّام", "سهيل", "حمزه", "ساهر", "ساري", "نيروز", "راسل", "حاتم", "باهي", "عاصم", "راجي", "جاد", "ثامر", "اديب", "ادم", "ادهم", "شادي", "سفيان", "بَشار", "بدر", "باهر", "أنس", "أمجد", "وافي", "هاشم", "نبراس", "نيار", "نادر", "مصطفي", "معاذ", "مصعب", "مشاري", "لامي", "فراس", "غسان", "عمار", "طاهر", "صفوان", "ريان", "زهير", "داني", "حيدر", "تامر", "مروان", "عادل", "تركي", "مهند", "كاظم", "بسام", "لؤي", "كنان", "نايف", "خاطر", "سعيد", "ابراهيم", "محمد", "حسام", "محمود"]
    if getList:
        return names + names0
    if arabic:
        return random.choice(names0)
    else:
        return random.choice(names)








def run(session):
  try:
    asyncio.new_event_loop().run_until_complete(main(session))
  except Exception as e:
    print(e)



while True:
 try:
  tasks = []
  tasks0 = tasksdb.get()["msg"]
  i = 1000000000
  for task in tasks0:
      d = get_task(task["link"],task["key"])
      if task["status"] == 0 and d == 0:
        if task["current"] == session:
          tasks.append(task)
        else:
          if int(task["current"]) < i:
            i = task["current"]
      elif task["status"] == 0 and d > 0:
        if task["current"]+d == session:
          tasks.append(task)
        else:
          if int(task["current"]+d) < i:
            i = task["current"]+d
  sort_tasks()
  if len(tasks) > 0:
    
    getSessions()
    
    
    
    if session >= len(sessions):
        session = 0
        users = usersdb.get()["msg"]
        server = serverdb.get()["msg"][0]
        for task in tasks0:
          d = get_task(task["link"],task["key"])
          if task["status"] == 0 and task["current"]+d >= session:
            
            task["status"] = 2
            task["error"] = "not enough sessions"
            tasksdb.edit(task)
            tasks.remove(task)
            user = None
            if "votes" in task:
                p = int(server["vote_points"])
                a = int(task["votes"])-int(task["current"])
                n = "التصويتات"
                all = task["votes"]
            elif "bot_referrals" in task:
                p = int(server["bot_referrals_points"])
                a = int(task["referrals"])-int(task["current"])
                n = "الاحالات"
                all = task["referrals"]
            elif "reacts" in task:
                p = int(server["react_points"])
                a = int(task["reacts"])-int(task["current"])
                n = "التفاعلات"
                all = task["reacts"]
            for u in users:
                if str(u["uid"]).strip() == str(task["user"]).strip():
                    print("user : "+str(u["uid"]))
                    u["points"] += a * p
                    usersdb.edit(u)
                    msg = "- عزيزى المستخدم لم يتم إكمال طلبك بالكامل, و السبب لأنك وصلت للحد الأقصى لهذا الرابط بإجمالى ("+str(task['current']+d)+"), تم ايقاف طلبك و إرجاع ("+str(a)+") نقاط ."
                    bot.send_message(task["user"],msg)
                    msg = """
* - تم انتهاء تصويتات* ☑️

*~> المنشور *: [{}]({})
*~> {} الكلية *: {} .
*~> {} الحالية *: {} .
*~> النقاط المخصومه *: {} نقطة
*~> حالة طلبك *: تم الايقاف

<+> الرجاء عدم حذف هذه الرسالة الا عند الانتهاء, لأنه يتم تعديلها تلقائيا .
"""
                    msg = msg.format(task["link"],task["link"],n,all,n,task["current"],task["current"]*p)
                    bot.edit_message_text(chat_id=task["user"],text=msg,message_id=task["msg_id"],parse_mode="markdown", disable_web_page_preview=True)
                    break
        
    
    
    if not sessions:
        print("This Script Didn't Have Any Sessions, Waiting To Add It ...")
        while True:
            time.sleep(600)
            getSessions()
            if sessions:
                break
    
    #for s in sessions:
        #if not "running" in s:
            #s["running"] = False
            #sessionsdb.edit(s)
        #elif s["running"]:
            #s["running"] = False
            #sessionsdb.edit(s)
    
    
    disconnect = False
    
    if len(tasks) > 0:
        if session > 0:
          run(session)
          session += 1
        elif sessions:
          run(0)
          session += 1
        else:
          print("No Sessions Avalible")
  else:
    os.system("clear")
    print("waiting orders ...")
    if i < 1000000000:
      session = i
    time.sleep(10)
 except Exception as e:
  print(e)
 time.sleep(10)
  
 






























