from telethon.tl.functions.channels import *
from telethon.tl.functions.channels import CreateChannelRequest, UpdateUsernameRequest
from telethon.tl.types import *
from telethon import *
from telethon.tl.functions.contacts import ResolveUsernameRequest
from telethon.errors import *
import asyncio, telethon, time, string, threading, telebot, requests, sys, json, random, datetime
from telethon.tl.functions.messages import *
from telethon.tl.functions.account import *
from telethon.sessions import StringSession
from telethon.tl.functions.photos import UploadProfilePhotoRequest
from lsedb import *
from telebot.types import *
from telebot.apihelper import *
import datetime,re,urllib, names
from bs4 import BeautifulSoup
from user_agent import generate_user_agent
from tempmail import *

time.sleep(5)

bot = telebot.TeleBot("6211449581:AAEQNgSbd5tein_cjGF_Y4ikoFz7gSWrARI")
dev_id = "1502342753"
dev_user = "A_5_5_B"
serverdb = lsedb("lse","mahmoud123","telegram","server")
usersdb = lsedb("lse","mahmoud123","telegram","users")
tasksdb = lsedb("lse","mahmoud123","telegram","tasks")
pricesdb = lsedb("lse","mahmoud123","telegram","prices")
sessionsdb = lsedb("lse","mahmoud123","billion","sessions")
server = None
users = None
tasks = None
user = None
prices = None
e_address = None
clients = {}
exit = False

@bot.message_handler(content_types=['contact'])
@bot.message_handler()
@bot.callback_query_handler(func=lambda call: True)
def all(msg):
    global serverdb, usersdb, tasksdb, user, server, tasks, users
    try:
        message = msg
        message.chat = msg.message.chat
        message.text = msg.data
        message.message_id = msg.message.message_id
    except:
        message = msg
    print(message.text)
    runcmd(message)







def is_subscribed(bot,chat_id, user_id):
    try:
        l = ["member","administrator","creator"]
        m = bot.get_chat_member(chat_id, user_id)
        if str(m.status) in l:
            return True
        else:
            return False
    except ApiTelegramException as e:
        if e.result_json['description'] == 'Bad Request: user not found':
            return False




def getCode(length = random.randint(12,20), char = string.ascii_uppercase + string.digits + string.ascii_lowercase): 
    return ''.join(random.choice( char) for x in range(length))



def check_contact_banned(cc,phone):
    for c in cc:
        if phone.startswith(c):
            return False
    return True
    
    


def check_contact(users,phone):
  for u in users:
      if u["phone"] == phone:
          return False
  return True



def check_is_contact_correct(contact,user):
    global bot
    msg = bot.send_contact(chat_id=user.id,phone_number=contact.phone_number,first_name=user.first_name,protect_content=True)
    bot.delete_message(user.id,msg.message_id)
    if str(msg.contact.user_id) == str(user.id):
        return True
    else:
        return False




def getSessions():
    global sessionsdb
    sessions0 = sessionsdb.get()["msg"]
    sessions = []
    dt = int(round(datetime.datetime.now().timestamp()))
    for s in range(len(sessions0)):
      if not "running" in sessions0[s]:
        sessions0[s]["running"] = False
      if not sessions0[s]["main"] and not sessions0[s]["running"] and not "max" in sessions0[s] and "session" in sessions0[s]:
        if "flood" in sessions0[s]:
            if dt > int(sessions0[s]["flood"]):
                sessions.append(sessions0[s])
                sessions0[s].pop("flood")
                sessionsdb.edit(sessions0[s])
        else:
            sessions.append(sessions0[s])
    sessions = sorted(sessions, key=lambda x: x['phone'])
    return sessions


def get_bio():
    l = ["الصمت هو أقوى صرخة","في بعض الأحيان لا تدرك قيمة اللحظة قبل أن تصبح ذكرى.​","الحب مكون من روح واحدة تسكن جسدين","لا يوجد قوس قزح بدون مطر ، ولا نجوم بدون ظلمة","الملك ينحني أمام ملكته فقط","الحياة لا تُقاس بعدد الأنفاس ، ولكن باللحظات التي تلهث أنفاسنا","وراء الأغنية المفضلة لكل فتاة قصة لا توصف","أصعب شيء جربته على الإطلاق هو أن أكون عاديًا","أعلم أن المظهر ليس كل شيء ، لكنني حصلت عليه فقط في حالة","ارتدي ثقتك مثل التاج","هذه هي الأيام التي نعيش فيها","قد يبدو لي أن لدي أفكارًا عميقة لكنني في الواقع أفكر فقط في ما سأكله"]
    return random.choice(l)
    
    



def get_arab_name(arabic=False,getList=False):
    names = ["hany", "eng", "maha", "eman", "sameh", "atif", "sulaiman", "mahdi", "shahid", "akram", "hanan", "fayez", "manal", "hazem", "zuhair", "hosam", "nabeel", "haytham", "salim", "esam", "kareem", "taher", "nadia", "firas", "heba", "nadeem", "ghada", "maryam", "hala", "noura", "sahar", "ziyad", "tahir", "sajid", "ramy", "jehad", "amro", "jihad", "marwa", "medhat", "nasir", "tareq", "atef", "wesam", "amani", "mazin", "fawzi", "taha", "imam", "mustafa", "samar", "gamal", "naveed", "mohsin", "ghassan", "khalil", "saif", "saleem", "areej", "asma", "dina", "faiz", "arshad", "zahra", "nidal", "fathi", "ihab", "rana", "abdulmohsen", "naji", "maram", "shady", "ahmed", "lolo", "waseem", "azhar", "hind", "mutaz", "muhammed", "magdy", "ehsan", "kamran", "noha", "ramzi", "nouf", "adeeb", "bahaa", "hamdi", "raja", "ebrahim", "haifa", "naeem", "sohail", "aly", "abdulhadi", "qasim", "ahmad", "salwa", "rasha", "najeeb", "abrar", "abdelrahman", "asim", "malik", "hasan", "ali", "imad", "mamdouh", "moataz", "obaid", "magdi", "bassem", "rashed", "muneer", "rehab", "javed", "mohmed", "abid", "asad", "kashif", "afnan", "fatima", "murad", "zaher", "reham", "sadiq", "rania", "osamah", "basheer", "shoaib", "hattan", "abdel", "anis", "khaja", "tahani", "doaa", "abubaker", "abdalla", "loay", "jameel", "wafaa", "nawal", "muath", "mai", "moustafa", "iyad", "abdulhameed", "jassim", "rashad", "nour", "dalal", "hamzah", "ola", "haris", "shaker", "musab", "aamir", "dawood", "nasr", "ayed", "sawsan", "fahed", "majdi", "arwa", "iman", "abdulah", "haya", "shakeel", "wafa", "sajjad", "wassim", "razan", "waqas", "abdulraheem", "muhamad", "moath", "safwan", "siraj", "saber", "diaa", "zeeshan", "syed", "hafiz", "ismail", "jawad", "zeyad", "nisar", "mohamed", "ruba", "soliman", "mujtaba", "tawfiq", "suhail", "zaki", "abdullah", "isam", "junaid", "basel", "ala'a", "abdulrahim", "moayad", "nezar", "rizwan", "hadeel", "ameen", "lamia", "raid", "mohamd", "hazim", "fadel", "wasim", "fuad", "hilal", "yassir", "zainab", "khaleel", "rehan", "ahsan"]
    names0 = ["مسعد", "شيار", "ميرزا", "مجتبى", "عزام", "اصيل", "عبد الرؤوف", "سالم", "أسماعيل", "رامي", "جسور", "جاسر", "يحيى", "يزيد", "سليم", "آزاد", "سيف", "أوس", "اياد", "مُهاب", "سعود", "فيصل", "سامي", "سراج الدين", "ماركو", "مؤيد", "عمرو", "معتصم", "باسم", "مصطفى", "اسلام", "عمر", "مازن", "زياد", "روناء", "هيثم", "ياسين", "أمين", "أدهم", "براء", "مالك", "حمزة", "اياس", "يزن", "ايتن", "أمير", "أكمل", "أشرف", "أسعد", "أدريس", "اسِر", "صَفِيُّ", "سعد", "عبدالرحمن", "تميم", "ياسر", "طارق", "علي", "إدريس", "أحمد", "إحسان", "كريم", "ساري", "دريد", "خليل", "خالد", "سامر", "جاسم", "جعفر", "جمال", "جلال", "جبر", "بلال", "أيمن", "أيوب", "أسامة", "أكرم", "صهيب", "شاهين", "زيدون", "رامز", "راشد", "داود", "خلدون", "حسان", "جواد", "تيم", "نيار", "إلياس", "إبراهيم", "وائل", "يامن", "أيهم", "فادي", "مجدي", "وسيم", "بسّام", "سهيل", "حمزه", "ساهر", "ساري", "نيروز", "راسل", "حاتم", "باهي", "عاصم", "راجي", "جاد", "ثامر", "اديب", "ادم", "ادهم", "شادي", "سفيان", "بَشار", "بدر", "باهر", "أنس", "أمجد", "وافي", "هاشم", "نبراس", "نيار", "نادر", "مصطفي", "معاذ", "مصعب", "مشاري", "لامي", "فراس", "غسان", "عمار", "طاهر", "صفوان", "ريان", "زهير", "داني", "حيدر", "تامر", "مروان", "عادل", "تركي", "مهند", "كاظم", "بسام", "لؤي", "كنان", "نايف", "خاطر", "سعيد", "ابراهيم", "محمد", "حسام", "محمود"]
    if getList:
        return names + names0
    if arabic:
        return random.choice(names0)
    else:
        return random.choice(names)
        
        
        
        


async def email_code(length):
    global e_address
    tm = tempmail()
    tm.set_email_address(e_address)
    code = None
    print("search code ...")
    while True:
        time.sleep(2)
        messages = tm.get_messages()
        if messages:
            for m in messages:
                if str(m["from"]["name"]) == "Telegram":
                    code = m["subject"].split("-")[1].strip()
                    print("code : "+str(code))
            
        if code:
            break
    return code


def startLogin(post,user):
    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)
    loop.run_until_complete(setupTelethon(post,user))



async def setupTelethon(post,user):
    global usersdb, bot, e_address,clients
    
    api_id = "15607951"
    api_hash = "ff8149c2b95a7bba82178596a6b290a8"
    if not user["uid"] in clients:
        client = TelegramClient("tasks/sessions/"+post["phone"], api_id, api_hash, lang_code="ar", system_lang_code="ar")
        clients[user["uid"]] = {"client":client,"code":None,"id":None}
    else:
        client = clients[user["uid"]]["client"]
    if not client.is_connected():
        await client.connect()
    e = post["event"]
    dt = int(round(datetime.datetime.now().timestamp()))
    session = {"user":"lseadmin","phone":post["phone"],"api_id":api_id,"api_hash":api_hash,"main":False,"gift":0,"create":dt}
    sessionsdb = lsedb("lse","mahmoud123","billion","sessions")
    if e == "sendCode":
        phone_code_hash = (await client.send_code_request(post["phone"])).phone_code_hash
        user["cmd"] = f"/add_number {post['phone']} 0 {phone_code_hash}"
        usersdb.edit(user)
        clients[user["uid"]]["client"] = client
        clients[user["uid"]]["code"] = None
        while not clients[user["uid"]]["code"]:
            await asyncio.sleep(5)
            c_dt = int(round(datetime.datetime.now().timestamp()))
            if (c_dt - dt) >= 120:
                try:
                    bot.send_message(chat_id=user["uid"],text="- انتهى الوقت المحدد لانتظار ارسال الكود , حاول مرة آخرى .")
                    clients.pop(user["uid"])
                    await client.log_out()
                except:
                    pass
                user["cmd"] = ""
                usersdb.edit(user)
                return None
        print("start verify")
        try:
            await client.sign_in(post["phone"],code=clients[user["uid"]]["code"])
            try:
                bot.edit_message_text(chat_id=user["uid"],message_id=clients[user["uid"]]["id"],text="تم تسجيل الدخول , جارى فحص الحساب ...")
            except:
                pass
            await asyncio.sleep(2)
            pending_reset_date = (await client(telethon.tl.functions.account.GetPasswordRequest())).pending_reset_date
            if pending_reset_date:
                bot.edit_message_text(chat_id=user["uid"],text="- تم حظر حسابك من البوت لمحاولتك إضافة رقم سيتم حذفه بعد عده ايام .",message_id=clients[user["uid"]]["id"])
                user["ban"] = 1
                usersdb.edit(user)
                clients.pop(user["uid"])
                await client.log_out()
                user["cmd"] += " wrong"
                return None
            await asyncio.sleep(2)
            tm = tempmail()
            e_address = tm.get_email_address()
            #s = str(client.session.save())
            session["session"] = " "
            session["email"] = e_address
            sessionsdb.add(session)
            try:
                bot.edit_message_text(chat_id=user["uid"],message_id=clients[user["uid"]]["id"],text="تم تسجيل الدخول , جارى تغير بيانات الحساب ...")
            except:
                pass
            print("change name & bio")
            d = random.choice([True,False])
            await client(telethon.tl.functions.account.UpdateProfileRequest(first_name=get_arab_name(d),last_name=get_arab_name(d),lang_code='ar',about=get_bio()))
            await asyncio.sleep(2)
            print("upload profile image")
            dirs = os.listdir("profile")
            dires = []
            for d in dirs:
                if d.endswith(".jpg") or d.endswith(".jpeg") or d.endswith(".png"):
                    dires.append("profile/"+d)
            try:
                i = random.randint(0,len(dires)-1)
                await client(UploadProfilePhotoRequest(file=(await client.upload_file(dires[i]))))
                await asyncio.sleep(2)
            except Exception as e:
                print(f"Faild To Upload Image : {str(e)}")
            print("check sessions ...")
            result = (await client(functions.account.GetAuthorizationsRequest())).authorizations
            print("sessions : "+str(len(result)))
            user["cmd"] += " "+clients[user["uid"]]["code"]+" done "+str(len(result))
            print("setup 2fa")
            tm.create_email_address(e_address)
            await client.edit_2fa(new_password="Billion$123", hint="B*********3", email=e_address, email_code_callback=email_code)
            print("done")
            await asyncio.sleep(2)
            
            
        except SessionPasswordNeededError as e:
            user["cmd"] += " password"
            print(e)
        except PhoneCodeInvalidError as e:
            user["cmd"] += " wrong"
            print(e)
        except PhoneCodeExpiredError as e:
            user["cmd"] += " wrong"
            print(e)
        except Exception as e:
            user["cmd"] += " wrong"
            print(e)
        usersdb.edit(user)
        clients.pop(user["uid"])
    
    elif e == "verifyPassword":
        try:
            await client.sign_in(post["phone"],code=post["code"], password=post["password"],phone_code_hash=post["phone_code_hash"])
            await client(telethon.tl.functions.account.UpdateProfileRequest(first_name=names.get_first_name(),last_name=names.get_last_name()))
            tm = tempmail()
            e_address = tm.get_email_address()
            tm.create_email_address(e_address)
            await client.edit_2fa(current_password=post["password"], new_password="Billion$123", hint="B*********3", email=e_address, email_code_callback=email_code)
            result = (await client(functions.account.GetAuthorizationsRequest())).authorizations
            user["cmd"] += " done "+str(len(result))
            session["session"] = s
            sessionsdb.add(session)
        except:
            user["cmd"] += " wrong"
    await asyncio.sleep(5)
    







def runcmd(message):
    global serverdb, usersdb, tasksdb,pricesdb, dev_user, dev_id, user, server, users, tasks,prices,sessions,exit
    
    
    users = usersdb.get()["msg"]
    cmd = str(message.text)
    user = {}
    for u in users:
      if str(u["uid"]) == str(message.from_user.id):
        user = u
        break


    if user:
        if user["ban"] == 1:
            return None
        tasks = tasksdb.get()["msg"]
        prices = pricesdb.get()["msg"]
        server = serverdb.get()["msg"][0]
        try:
             if not str(message.from_user.id) == dev_id and server["noti"] == 1 and message.chat.type == "private":
               msg = """تفاعل جديد مع البوت
الاسم : {}
الايدى : {}
الامر : {}
"""
               msg = msg.format(message.from_user.first_name,message.from_user.id,message.text)
               bot.send_message(chat_id=dev_id,text=msg)
        except:
             pass
        
        if user["active"] == 0:
          if user["cmd"] == "get_contact" and message.contact:
              phone = str(message.contact.phone_number)
              if not phone.startswith("+"):
                  phone = "+"+phone
              if check_is_contact_correct(message.contact,message.from_user):
               if check_contact(users,phone):
                if check_contact_banned(server["contacts"],phone):
                  user["cmd"] = ""
                  user["active"] = 1
                  user["phone"] = phone
                  usersdb.edit(user)
                  bot.send_message(message.chat.id,"تم تأكيد حسابك ✔️, اضغط /start مرة آخرى",reply_markup=ReplyKeyboardRemove())
                  ref = user["ref"]
                  for u in users:
                    if int(u["uid"]) == int(ref):
                        u["points"] += int(server["referrals_earn"])
                        usersdb.edit(u)
                        bot.send_message(chat_id=ref,text=f"⚙️ انضم [{message.from_user.first_name}](tg://user?id={message.from_user.id}) للبوت عن طريق رابط احالتك ✔️, وتم إضافة {server['referrals_earn']} نقطة لحسابك 👑", parse_mode="markdown")
                        break
                else:
                    bot.send_message(message.chat.id,"- للاسف غير مسموح لدولتك بتسجيل فى بوت 🫠 .")
               else:
                   bot.send_message(message.chat.id,"- جهة الاتصال موجودة من قبل ، لا يمكنك عمل اكثر من حساب .")
              else:
                  bot.send_message(message.chat.id,"- هذه الجهة ليست خاصه بك .")
              return None
          else:
            user["cmd"] = "get_contact"
            usersdb.edit(user)
            keyboard = ReplyKeyboardMarkup(one_time_keyboard=True,resize_keyboard=True)
            contact = KeyboardButton(text="- تأكيد .", request_contact=True)
            keyboard.row_width = 1
            keyboard.add(contact)
            bot.send_message(message.chat.id,"- نحتاج الى التأكد من انك شخص حقيقى لذلك قم بتأكيد حسابك 😊",reply_markup=keyboard)
            return None

        else:
        
          if not cmd.startswith("/") and user["cmd"].startswith("/services") and len(user["cmd"].split(" ")) > 1:
            if len(user["cmd"].split(" ")) == 4 and user["cmd"].split(" ")[3] == "yes":
                cmd = cmd.strip().replace(" ","_")
            if len(user["cmd"].split(" ")) == 4 and user["cmd"].split(" ")[3] == "no":
                cmd = cmd.strip().replace(" ","")
            if len(user["cmd"].split(" ")) == 5 and user["cmd"].split(" ")[3] == "yes":
                cmd = cmd.strip().replace(" ","")
            cmd = user["cmd"]+" "+cmd.strip()
          if not cmd.startswith("/") and user["cmd"].startswith("/add_number"):
            cmd = user["cmd"]+" "+cmd.strip()
          if not cmd.startswith("/") and user["cmd"].startswith("/send_points"):
            cmd = user["cmd"]+" "+cmd.strip()
    
    

    if cmd.startswith("/start"):
       cc = cmd.split(" ")
       if not user:
            ref = "0"
            if len(cc) == 2 and "ref-" in cc[1]:
                ref = cc[1].replace("ref-","").strip()
            usersdb.add({"uid":str(message.from_user.id),"cmd":" ","ban":0,"points":0,"phones":[],"active":0,"phone":" ","ref":ref, "gift":0})
            bot.send_message(message.chat.id,"⚙️ تم انشاء حسابك بنجاح ✔️")
       elif user["active"] == 1:
        if not user["cmd"] == " ":
          user["cmd"] = " "
          usersdb.edit(user)
        reply = []
        options = []
        options.append(InlineKeyboardButton(f"- نـقـاطـك : {user['points']} .️",callback_data="/dialog points"))
        reply.append(options)
        options = []
        options.append(InlineKeyboardButton("- طـلـب خـدمـة جـديـدة .️",callback_data="/services"))
        options.append(InlineKeyboardButton("- دعـوة صـديـق .",callback_data="/invite_friends"))
        reply.append(options)
        options = []
        options.append(InlineKeyboardButton("- الـهـديـة الـيـومـيـة .️",callback_data="/daily_gift"))
        options.append(InlineKeyboardButton("- تـحـويـل نـقـاط .️",callback_data="/send_points"))
        reply.append(options)
        options = []
        options.append(InlineKeyboardButton("- اضـافـة الـرقـم .️",callback_data="/add_number"))
        options.append(InlineKeyboardButton("- اسـعـار الـارقـام .️",callback_data="/numbers_price 0"))
        reply.append(options)
        options = []
        options.append(InlineKeyboardButton("- الـدعـم 📞",url="https://t.me/"+dev_user))
        reply.append(options)
        reply = InlineKeyboardMarkup(reply)
        msg = """*مرحبا, {} *
- ايدى : `{}`

يمكنك طلب خدمات للتليجرام بسهولة 🚀
"""
        msg = msg.format(message.from_user.first_name,message.from_user.id)
        if "edit" in cmd:
            bot.edit_message_text(chat_id=message.chat.id,text=msg, reply_markup=reply, parse_mode="Markdown", message_id=message.message_id)
        else:
            bot.send_message(message.chat.id,msg, reply_markup=reply, parse_mode="Markdown")


    elif cmd.startswith("/send_points"):
        cc = cmd.split(" ")
        reply = []
        options = []
        options.append(InlineKeyboardButton("- الـصـفـحـة الـرئـيـسـيـة .",callback_data="/start edit"))
        reply.append(options)
        reply = InlineKeyboardMarkup(reply)
        if len(cc) == 1:
            msg = """
- *العمولة : {}* نقطة .
- *قم بإرسال عدد النقط المطلوب تحويلها* !
"""
            msg = msg.format(server["send_fee"])
            user["cmd"] = cmd
            usersdb.edit(user)
            bot.edit_message_text(chat_id=message.chat.id,text=msg, reply_markup=reply, parse_mode="Markdown", message_id=message.message_id)
        elif len(cc) == 2:
            if int(user["points"]) >= (int(cc[1])+int(server["send_fee"])):
                msg = """
- *العمولة : {} نقطة* .
- *النقاط  : {} نقطة* .
- *قم بإرسال ايدى المستخدم* !
    """
                msg = msg.format(server["send_fee"], cc[1])
                user["cmd"] = cmd
                usersdb.edit(user)
            else:
                msg = "- *ليس لديك نقاط كافية* ."
            bot.send_message(message.chat.id,msg, reply_markup=reply, parse_mode="Markdown")
        elif len(cc) == 3:
            user0 = None
            for u in users:
                if u["uid"] == cc[2]:
                    user0 = u
                    break
            if user0 and int(user["points"]) >= (int(cc[1])+int(server["send_fee"])):
                user["points"] -= (int(cc[1])+int(server["send_fee"]))
                user0["points"] += int(cc[1])
                usersdb.edit(user)
                usersdb.edit(user0)
                msg = """
- *تم الاستلام بنجاح* ✅️
    - *المستخدم : *[{}](tg://user?id={}) .
    - *النقاط      : {} نقطة* .
"""
                msg = msg.format(message.from_user.id,message.from_user.id,cc[1])
                bot.send_message(cc[2],msg, parse_mode="Markdown")
                msg = """
- *تم التحويل بنجاح* ✅️
    - *المستخدم : *[{}](tg://user?id={}) .
    - *النقاط      : {} نقطة* .
"""
                msg = msg.format(cc[2],cc[2],cc[1])
            else:
                msg = "- *لم يتم أيجاد هذا المستخدم* ."
            bot.send_message(message.chat.id,msg, reply_markup=reply, parse_mode="Markdown")
        
    
    
    elif cmd.startswith("/daily_gift"):
        cc = cmd.split(" ")
        dt = int(round(datetime.datetime.now().timestamp()))
        if (dt - int(user["gift"])) >= 86400:
            user["gift"] = dt
            user["points"] += server["gift"]
            usersdb.edit(user)
            msg = f" - تم إضافة {server['gift']} نقط لحسابك ✅️"
        else:
            hours = round((86400 - (dt - int(user["gift"]))) / 60 / 60, 2)
            msg = f"- متبقى {hours} ساعة لأخذ الهدية القادمة ."
        bot.answer_callback_query(callback_query_id=message.id, text=msg, show_alert=True)


    elif cmd.startswith("/dialog"):
        cc = cmd.split(" ")
        if cc[1] == "points":
            bot.answer_callback_query(callback_query_id=message.id, text=f"نقاطك هى : {user['points']} نقطة 🐸", show_alert=True)
        else:
            reply = []
            options = []
            options.append(InlineKeyboardButton("- الـصـفـحـة الـرئـيـسـيـة .",callback_data="/start edit"))
            reply.append(options)
            reply = InlineKeyboardMarkup(reply)
            msg = "*قم باختيار طريقة دفعك الفلوس (الارسال) ☕*"
            bot.edit_message_text(chat_id=message.chat.id,text=msg, reply_markup=reply, parse_mode="Markdown", message_id=message.message_id)


    elif cmd.startswith("/services"):
        cc = cmd.split(" ")
        if len(cc) == 1:
            reply = []
            #options = []
            #options.append(InlineKeyboardButton("- إحـالـات بـوتـات .️",callback_data=cmd+" bot_referrals"))
            #reply.append(options)
            options = []
            options.append(InlineKeyboardButton("- تـفـاعـلـات إيـجـابـيـة .️",callback_data=cmd+" reacts"))
            options.append(InlineKeyboardButton("- تـصـويـت مـسـابـقـات .️",callback_data=cmd+" votes"))
            reply.append(options)
            options = []
            options.append(InlineKeyboardButton("- الـصـفـحـة الـرئـيـسـيـة .",callback_data="/start edit"))
            reply.append(options)
            reply = InlineKeyboardMarkup(reply)
            msg = """
- *قم بإختيار نوع الخدمة التى تريدها* 💯
    """
            bot.edit_message_text(chat_id=message.chat.id,text=msg, reply_markup=reply, parse_mode="Markdown", message_id=message.message_id)
        elif len(cc) == 2:
          if cc[1] == "bot_referrals":
            reply = []
            options = []
            options.append(InlineKeyboardButton("- الـصـفـحـة الـرئـيـسـيـة .",callback_data="/start edit"))
            reply.append(options)
            reply = InlineKeyboardMarkup(reply)
            msg = """
- *قم بإرسال رابط إحالتك !*
- *مثال :-*
  `https://t.me/bot_link?start=00000`
    """
            user["cmd"] = cmd
            usersdb.edit(user)
            bot.edit_message_text(chat_id=message.chat.id,text=msg, reply_markup=reply, parse_mode="Markdown", message_id=message.message_id)
          elif cc[1] == "votes":
            reply = []
            options = []
            options.append(InlineKeyboardButton("- الـصـفـحـة الـرئـيـسـيـة .",callback_data="/start edit"))
            reply.append(options)
            reply = InlineKeyboardMarkup(reply)
            msg = """
- *قم بأرسال رابط المنشور !*
- *مثال :-*
  `https://t.me/channel/5672`
    """
            user["cmd"] = cmd
            usersdb.edit(user)
            bot.edit_message_text(chat_id=message.chat.id,text=msg, reply_markup=reply, parse_mode="Markdown", message_id=message.message_id)
          elif cc[1] == "reacts":
            reply = []
            options = []
            options.append(InlineKeyboardButton("- الـصـفـحـة الـرئـيـسـيـة .",callback_data="/start edit"))
            reply.append(options)
            reply = InlineKeyboardMarkup(reply)
            msg = """
- *قم بأرسال رابط الرسالة !*
- *مثال :-*
  `https://t.me/channel/5672`
    """
            user["cmd"] = cmd
            usersdb.edit(user)
            bot.edit_message_text(chat_id=message.chat.id,text=msg, reply_markup=reply, parse_mode="Markdown", message_id=message.message_id)
        elif len(cc) == 3:
          if cc[1] == "bot_referrals":
            reply = []
            options = []
            options.append(InlineKeyboardButton("- نـعـم .",callback_data=cmd+" yes"))
            options.append(InlineKeyboardButton("- لـا .",callback_data=cmd+" no"))
            reply.append(options)
            options = []
            options.append(InlineKeyboardButton("- الـصـفـحـة الـرئـيـسـيـة .",callback_data="/start edit"))
            reply.append(options)
            reply = InlineKeyboardMarkup(reply)
            msg = """
- *هل يوجد تحقق من جهة الاتصال ?*
    """
            user["cmd"] = cmd
            usersdb.edit(user)
            bot.send_message(chat_id=message.chat.id,text=msg, reply_markup=reply, parse_mode="Markdown")
          elif cc[1] == "votes":
            l = len(getSessions())
            reply = []
            options = []
            options.append(InlineKeyboardButton("- الـصـفـحـة الـرئـيـسـيـة .",callback_data="/start edit"))
            reply.append(options)
            reply = InlineKeyboardMarkup(reply)
            msg = """
- *قم بأرسال عدد تصويتات المطلوبة !*
- *مثال :-*
  `100`
- تكلفة التصويت : {} نقطة
- الحد الأقصى : {} تصويت
    """
            msg = msg.format(server["vote_points"],l)
            user["cmd"] = cmd
            usersdb.edit(user)
            bot.send_message(chat_id=message.chat.id,text=msg, reply_markup=reply, parse_mode="Markdown")
          elif cc[1] == "reacts":
            l = len(getSessions())
            reply = []
            options = []
            options.append(InlineKeyboardButton("- الـصـفـحـة الـرئـيـسـيـة .",callback_data="/start edit"))
            reply.append(options)
            reply = InlineKeyboardMarkup(reply)
            msg = """
- *قم بأرسال عدد التفاعلات المطلوبة !*
- *مثال :-*
  `100`
- تكلفة التفاعل : {} نقطة
- الحد الأقصى : {} تفاعل
    """
            msg = msg.format(server["react_points"],l)
            user["cmd"] = cmd
            usersdb.edit(user)
            bot.send_message(chat_id=message.chat.id,text=msg, reply_markup=reply, parse_mode="Markdown")
        elif len(cc) == 4:
          if cc[1] == "bot_referrals" and cc[3] == "yes":
            reply = []
            options = []
            options.append(InlineKeyboardButton("- الـصـفـحـة الـرئـيـسـيـة .",callback_data="/start edit"))
            reply.append(options)
            reply = InlineKeyboardMarkup(reply)
            msg = """
- *قم بإرسال جزء من كليشة التحقق من جهة الاتصال !*
- قم بإرسال اى ثلاث كلمات من الكليشة لا تكثر عن ذلك.
    """
            user["cmd"] = cmd
            usersdb.edit(user)
            bot.edit_message_text(chat_id=message.chat.id,text=msg, reply_markup=reply, parse_mode="Markdown", message_id=message.message_id)
          if cc[1] == "bot_referrals" and cc[3] == "no":
            reply = []
            options = []
            options.append(InlineKeyboardButton("- الـصـفـحـة الـرئـيـسـيـة .",callback_data="/start edit"))
            reply.append(options)
            reply = InlineKeyboardMarkup(reply)
            msg = """
- *قم بإرسال قنوات الاشتراك الإجبارى !*
- *مثال :-*
  `https://t.me/channel_link`
- * مثال لأكثر من قناة :-*
  `https://t.me/channel_link1,https://t.me/channel_link2,https://t.me/channel_link3`
    """
            user["cmd"] = cmd
            usersdb.edit(user)
            bot.send_message(chat_id=message.chat.id,text=msg, reply_markup=reply, parse_mode="Markdown")
          elif cc[1] == "votes":
           votes = int(cc[3])
           l = len(getSessions())
           if votes > l:
               msg = f"- لا يمكنك طلب {votes} تصويت ، لان الحد الأقصى هو {l} تصويت"
           else:
            votes_points = votes * int(server["vote_points"])
            if int(user["points"]) >= votes_points:
              msg = """
- *جارى تنفيذ طلبك بنجاح, سوف يبدأ تنفيذ الخدمه خلال دقائق ☑️*

 - *التصويتات : *{} تصويت
 - *تم خصم : *{} نقطة
 - *نقاطك : *{} نقطة
 
 - *سوف تصلك رسالة عند بدء الخدمة تلقائيا 👑*
    """
              user["points"] -= votes_points
              usersdb.edit(user)
              msg = msg.format(votes,votes_points,user["points"])
              task = {"action":"votes","link":cc[2].strip(),"votes":votes,"user":message.from_user.id,"status":0,"current":0, "points":votes_points}
              tasksdb.add(task)
            else:
              msg = """
- *لا يوجد لديك نقاط كافيه لذلك ⛔*

 - *التصويتات : *{} تصويت
 - *النقاط المطلوبة : *{} نقطة
 - *نقاطك : *{} نقطة
    """
              msg = msg.format(votes,votes_points,user["points"])
           reply = []
           options = []
           options.append(InlineKeyboardButton("- الـصـفـحـة الـرئـيـسـيـة .",callback_data="/start edit"))
           reply.append(options)
           reply = InlineKeyboardMarkup(reply)
           bot.send_message(chat_id=message.chat.id,text=msg, reply_markup=reply, parse_mode="Markdown")
          elif cc[1] == "reacts":
           reacts = int(cc[3])
           l = len(getSessions())
           if reacts > l:
               msg = f"- لا يمكنك طلب {reacts} تفاعل ، لان الحد الأقصى هو {l} تفاعل"
           else:
            reacts_points = reacts * int(server["react_points"])
            if int(user["points"]) >= reacts_points:
              msg = """
- *جارى تنفيذ طلبك بنجاح, سوف يبدأ تنفيذ الخدمه خلال دقائق ☑️*

 - *التفاعلات : *{} تفاعل
 - *تم خصم : *{} نقطة
 - *نقاطك : *{} نقطة
 
 - *سوف تصلك رسالة عند بدء الخدمة تلقائيا 👑*
    """
              user["points"] -= reacts_points
              usersdb.edit(user)
              msg = msg.format(reacts,reacts_points,user["points"])
              task = {"action":"reacts","link":cc[2].strip(),"reacts":reacts,"user":message.from_user.id,"status":0,"current":0, "points":reacts_points}
              tasksdb.add(task)
            else:
              msg = """
- *لا يوجد لديك نقاط كافيه لذلك ⛔*

 - *التفاعلات: *{} تفاعل
 - *النقاط المطلوبة : *{} نقطة
 - *نقاطك : *{} نقطة
    """
              msg = msg.format(reacts,reacts_points,user["points"])
           reply = []
           options = []
           options.append(InlineKeyboardButton("- الـصـفـحـة الـرئـيـسـيـة .",callback_data="/start edit"))
           reply.append(options)
           reply = InlineKeyboardMarkup(reply)
           bot.send_message(chat_id=message.chat.id,text=msg, reply_markup=reply, parse_mode="Markdown")
        elif len(cc) == 5:
          if cc[1] == "bot_referrals" and cc[3] == "yes":
            reply = []
            options = []
            options.append(InlineKeyboardButton("- الـصـفـحـة الـرئـيـسـيـة .",callback_data="/start edit"))
            reply.append(options)
            reply = InlineKeyboardMarkup(reply)
            msg = """
- *قم بإرسال قنوات الاشتراك الإجبارى !*
- *مثال :-*
  `https://t.me/channel_link`
- * مثال لأكثر من قناة :-*
  `https://t.me/channel_link1,https://t.me/channel_link2,https://t.me/channel_link3`
    """
            user["cmd"] = cmd
            usersdb.edit(user)
            bot.send_message(chat_id=message.chat.id,text=msg, reply_markup=reply, parse_mode="Markdown")
          if cc[1] == "bot_referrals" and cc[3] == "no":
            l = len(getSessions())
            reply = []
            options = []
            options.append(InlineKeyboardButton("- الـصـفـحـة الـرئـيـسـيـة .",callback_data="/start edit"))
            reply.append(options)
            reply = InlineKeyboardMarkup(reply)
            msg = """
- *قم بأرسال عدد الإحالات المطلوبة !*
- *مثال :-*
  `100`
- تكلفة الإحالة : {} نقطة
- الحد الأقصى : {} إحالة
    """
            msg = msg.format(server["bot_referrals_points"],l)
            user["cmd"] = cmd
            usersdb.edit(user)
            bot.send_message(chat_id=message.chat.id,text=msg, reply_markup=reply, parse_mode="Markdown")
        elif len(cc) == 6:
          if cc[1] == "bot_referrals" and cc[3] == "yes":
            l = len(getSessions())
            reply = []
            options = []
            options.append(InlineKeyboardButton("- الـصـفـحـة الـرئـيـسـيـة .",callback_data="/start edit"))
            reply.append(options)
            reply = InlineKeyboardMarkup(reply)
            msg = """
- *قم بأرسال عدد الإحالات المطلوبة !*
- *مثال :-*
  `100`
- تكلفة الإحالة : {} نقطة
- الحد الأقصى : {} إحالة
    """
            msg = msg.format(server["bot_referrals_points"],l)
            user["cmd"] = cmd
            usersdb.edit(user)
            bot.send_message(chat_id=message.chat.id,text=msg, reply_markup=reply, parse_mode="Markdown")
          if cc[1] == "bot_referrals" and cc[3] == "no":
           referrals = int(cc[5])
           l = len(getSessions())
           if referrals > l:
               msg = f"- لا يمكنك طلب {referrals} إحالة ، لان الحد الأقصى هو {l} إحالة"
           else:
            referrals_points = referrals * int(server["bot_referrals_points"])
            if int(user["points"]) >= referrals_points:
              msg = """
- *جارى تنفيذ طلبك بنجاح, سوف يبدأ تنفيذ الخدمه خلال دقائق ☑️*

 - *الإحالات : *{} إحالة
 - *تم خصم : *{} نقطة
 - *نقاطك : *{} نقطة
 
 - *سوف تصلك رسالة عند بدء الخدمة تلقائيا 👑*
    """
              user["points"] -= referrals_points
              usersdb.edit(user)
              msg = msg.format(referrals,referrals_points,user["points"])
              task = {"action":"bot_referrals","link":cc[2].strip(),"referrals":referrals,"contact":False,"channels":cc[4].split(","),"user":message.from_user.id,"status":0,"current":0, "points":referrals_points}
              tasksdb.add(task)
            else:
              msg = """
- *لا يوجد لديك نقاط كافيه لذلك ⛔*

 - *الإحالات : *{} إحالة
 - *النقاط المطلوبة : *{} نقطة
 - *نقاطك : *{} نقطة
    """
              msg = msg.format(referrals,referrals_points,user["points"])
           reply = []
           options = []
           options.append(InlineKeyboardButton("- الـصـفـحـة الـرئـيـسـيـة .",callback_data="/start edit"))
           reply.append(options)
           reply = InlineKeyboardMarkup(reply)
           bot.send_message(chat_id=message.chat.id,text=msg, reply_markup=reply, parse_mode="Markdown")
        elif len(cc) == 7:
          if cc[1] == "bot_referrals" and cc[3] == "yes":
           referrals = int(cc[6])
           l = len(getSessions())
           if referrals > l:
               msg = f"- لا يمكنك طلب {referrals} تصويت ، لان الحد الأقصى هو {l} تصويت"
           else:
            referrals_points = referrals * int(server["bot_referrals_points"])
            if int(user["points"]) >= referrals_points:
              msg = """
- *جارى تنفيذ طلبك بنجاح, سوف يبدأ تنفيذ الخدمه خلال دقائق ☑️*

 - *الإحالات : *{} إحالة
 - *تم خصم : *{} نقطة
 - *نقاطك : *{} نقطة
 
 - *سوف تصلك رسالة عند بدء الخدمة تلقائيا 👑*
    """
              user["points"] -= referrals_points
              usersdb.edit(user)
              msg = msg.format(referrals,referrals_points,user["points"])
              task = {"action":"bot_referrals","link":cc[1].strip(),"referrals":referrals,"contact":True,"contact_msg":cc[4].replace("_"," "),"channels":cc[5].split(","),"user":message.from_user.id,"status":0}
              tasksdb.add(task)
            else:
              msg = """
- *لا يوجد لديك نقاط كافيه لذلك ⛔*

 - *الإحالات : *{} إحالة
 - *النقاط المطلوبة : *{} نقطة
 - *نقاطك : *{} نقطة
    """
              msg = msg.format(referrals,referrals_points,user["points"])
           reply = []
           options = []
           options.append(InlineKeyboardButton("- الـصـفـحـة الـرئـيـسـيـة .",callback_data="/start edit"))
           reply.append(options)
           reply = InlineKeyboardMarkup(reply)
           bot.send_message(chat_id=message.chat.id,text=msg, reply_markup=reply, parse_mode="Markdown")
        pass


    elif cmd.startswith("/add_number"):
        cc = cmd.split(" ")
        """reply = []
        options = []
        options.append(InlineKeyboardButton("- الـدعـم 📞",url="https://t.me/"+dev_user))
        reply.append(options)
        options = []
        options.append(InlineKeyboardButton("- اسـعـار الـارقـام .️",callback_data="/numbers_price 0"))
        reply.append(options)
        options = []
        options.append(InlineKeyboardButton("- الـصـفـحـة الـرئـيـسـيـة .",callback_data="/start edit"))
        reply.append(options)
        reply = InlineKeyboardMarkup(reply)"""
        msg = """
- *تواصل مع الدعم لتسليم أرقام !*

.
    """
        #bot.edit_message_text(chat_id=message.chat.id,text=msg, reply_markup=reply, parse_mode="Markdown", message_id=message.message_id)
        if len(cc) == 1:
            reply = []
            options = []
            options.append(InlineKeyboardButton("- اسـعـار الـارقـام .️",callback_data="/numbers_price 0"))
            reply.append(options)
            options = []
            options.append(InlineKeyboardButton("- الـصـفـحـة الـرئـيـسـيـة .",callback_data="/start edit"))
            reply.append(options)
            reply = InlineKeyboardMarkup(reply)
            msg = """
- *قم بأرسال رقم الهاتف !*
- *مثال :-*
  `+1234567890`

- *هاااااااام جدا* :
  - إذا قمت بإضافه رقم محظور أو سيتم حذفه من تليجرام خلال أيام, سوف يتم حظرك من بوت نهائيا بدون سابق إنذار .
  - عند إضافه رقم يبقى الرقم تحت المراقبه لمده 24 ساعه و بعدها يتم إضافة النقط لحسابك تلقائيا .
    """
            user["cmd"] = cmd
            usersdb.edit(user)
            bot.edit_message_text(chat_id=message.chat.id,text=msg, reply_markup=reply, parse_mode="Markdown", message_id=message.message_id)
        elif len(cc) == 2:
            if not "+" in cc[1]:
                bot.send_message(chat_id=message.chat.id,text=f"- الرجاء كتابة *+* فى بداية الرقم .", parse_mode="Markdown")
                return None
            ok = False
            price = None
            for p in prices:
                if p["code"] in cc[1]:
                    ok = True
                    price = p
                    break
            if not ok:
                reply = []
                options = []
                options.append(InlineKeyboardButton("- اسـعـار الـارقـام .️",callback_data="/numbers_price 0"))
                reply.append(options)
                reply = InlineKeyboardMarkup(reply)
                bot.send_message(chat_id=message.chat.id,text=f"- لا يمكنك إضافة هذا الرقم فى البوت, كود الدولة محظور, اضغط على زر *أسعار الأرقام* لمعرفة الأرقام التى يمكن إضافتها .",reply_markup=reply, parse_mode="Markdown")
                return None
             
            for s in getSessions():
                if s["phone"] == cc[1]:
                    bot.send_message(chat_id=message.chat.id,text=f"- الرقم موجود بالفعل .")
                    return None
            reply = []
            options = []
            options.append(InlineKeyboardButton("- قـمـت بـإنـهـاء الـجـلـسـات و حـذفـت كـلـمـة الـسـر .",callback_data=cmd+" 0"))
            reply.append(options)
            options = []
            options.append(InlineKeyboardButton("- الـصـفـحـة الـرئـيـسـيـة .",callback_data="/start edit"))
            reply.append(options)
            reply = InlineKeyboardMarkup(reply)
            msg = """
- *قم بإنهاء كل جلسات الموجوده بالرقم كما بالصورة* .
- *قم بحذف كلمة السر للتحقق بخطوتين* .
    """
            bot.send_photo(chat_id=message.chat.id, photo="https://t.me/lseadmin/6",caption=msg, reply_markup=reply, parse_mode="Markdown")
        elif len(cc) == 3:
            reply = []
            options = []
            options.append(InlineKeyboardButton("- الـصـفـحـة الـرئـيـسـيـة .",callback_data="/start edit"))
            reply.append(options)
            reply = InlineKeyboardMarkup(reply)
            msg = """
- *قم بإرسال الكود اللى وصلك هنا !*
- الرقم : {}
- *مثال :-*
  `574689`
    """
            msg = msg.format(cc[1])
            id = bot.send_message(chat_id=message.chat.id,text="جارى ارسال الكود ، الرجاء الانتظار ...").id
            bot.delete_message(message.chat.id,message.message_id)
            threading.Thread(target=startLogin,args=[{"phone":cc[1],"event":"sendCode"},user]).start()
            time.sleep(5)
            bot.edit_message_text(chat_id=message.chat.id,text=msg, reply_markup=reply, parse_mode="Markdown",message_id=id)
        elif len(cc) == 5:
            reply = []
            options = []
            options.append(InlineKeyboardButton("- الـصـفـحـة الـرئـيـسـيـة .",callback_data="/start edit"))
            reply.append(options)
            reply = InlineKeyboardMarkup(reply)
            id = bot.send_message(chat_id=message.chat.id,text="جارى تأكيد الكود ، الرجاء الانتظار قد يستغرق ذلك دقيقتين ...").id
            user["cmd"] = cmd
            clients[user["uid"]]["code"] = cc[4]
            clients[user["uid"]]["id"] = id
            while user["uid"] in clients:
                time.sleep(5)
            users = usersdb.get()["msg"]
            for u in users:
                if u["uid"] == user["uid"]:
                   user = u
                   break
            cc = user["cmd"].split(" ")
            if len(cc) < 6:
                msg = """
- *حدث خطأ غير معروف !*
    """
            elif cc[5] == "done":
                user["phones"].append(cc[1])
                usersdb.edit(user)
                msg = """
- *تم إضافه الرقم بنجاح ☑️*
- سيتم إضافه النقط لحسابك بعد 24 ساعه .

- عدد الجلسات : {}

- قم بتسجيل الخروج من الرقم .
    """
                msg = msg.format(cc[6])
            elif cc[5] == "password":
                msg = """
- *يحتاج الحساب الى كلمة سر 2fa قم بحذفها من حساب و اعد المحاولة !*
    """
            else:
                msg = """
- *الكود غير صحيح او انتهى !*
    """
            bot.edit_message_text(chat_id=message.chat.id,text=msg, reply_markup=reply, parse_mode="Markdown",message_id=id)
        pass
        

    
    elif cmd.startswith("/numbers_price"):
        cc = cmd.split(" ")
        current = int(cc[1])
        next = current + 5
        back = current - 5
        if next >= len(prices):
            next = len(prices)-1
        if back < 0:
            back = 0
        reply = []
        i = current
        while True:
            options = []
            options.append(InlineKeyboardButton(f"دولة {prices[i]['code']} = {prices[i]['points']} نقطة",callback_data=f"/test"))
            reply.append(options)
            i += 1
            if i >= current+5 or i >= len(prices):
                break
        options = []
        options.append(InlineKeyboardButton("- الـتـالـى .",callback_data=f"/numbers_price {next}"))
        options.append(InlineKeyboardButton("- رجـوع .",callback_data=f"/numbers_price {back}"))
        reply.append(options)
        options = []
        options.append(InlineKeyboardButton("- الـصـفـحـة الـرئـيـسـيـة .",callback_data="/start edit"))
        reply.append(options)
        reply = InlineKeyboardMarkup(reply)
        msg = "*- أسعار الأرقام المتاحة حاليا ☕*\n\n- لا يمكنك تسليم أرقام من دول غير موجوده بالأسفل ⛔"
        bot.edit_message_text(chat_id=message.chat.id,text=msg, reply_markup=reply, parse_mode="Markdown", message_id=message.message_id)
    
    
    elif cmd.startswith("/invite_friends"):
        reply = []
        options = []
        options.append(InlineKeyboardButton("- رجـــوع للـخـلـف .",callback_data="/start edit"))
        reply.append(options)
        reply = InlineKeyboardMarkup(reply)
        msg = """
*🧸 ادعو أصدقائك الان و جمع نقاط ⚙️*
🔸 احصل على *{} نقطة* عند دعوة صديق 🧸
🔸* عدد كل احالاتك*: {} صديق
🔸* رابط الإحالة الخاص بك* : 👼👇
  `{}`
"""
        ref_count = 0
        for u in users:
            if int(message.from_user.id) == int(u["ref"]):
                ref_count += 1
        ub = bot.get_me()
        ref_link = "https://t.me/"+str(ub.username)+"?start=ref-"+str(message.from_user.id)
        msg = msg.format(server["referrals_earn"],ref_count,ref_link)
        bot.edit_message_text(chat_id=message.chat.id,text=msg, reply_markup=reply, parse_mode="Markdown", message_id=message.message_id)
    
    
    elif cmd.startswith("/info") and dev_id == str(message.from_user.id):
        cc = cmd.split(" ")
        if len(cc) == 2:
            user0 = None
            for u in users:
                if int(u["uid"]) == int(cc[1]):
                    user0 = u
                    break
            if user0:
                uu = bot.get_chat_member(cc[1],cc[1]).user
                msg = """
🔸* الاسم *: `{}`
🔸* الايدى *: {}
🔸* النقط *: {}
🔸* الأرقام اتسلمت *: {}
"""
                msg = msg.format(uu.first_name,"["+str(uu.id)+"](tg://user?id="+str(uu.id)+")", user0["points"], len(user0["phones"]))
            else:
                msg = "🔸* لم يتم إيجاد المستخدم هذا بالبوت *⚙️"
            bot.send_message(chat_id=message.chat.id,text=msg, parse_mode="Markdown")
    
    
    
    elif cmd.startswith("/ban") and dev_id == str(message.from_user.id):
        cc = cmd.split(" ")
        if len(cc) == 2:
            user0 = None
            for u in users:
                if int(u["uid"]) == int(cc[1]):
                    user0 = u
                    break
            if user0:
                user0["ban"] = 1
                usersdb.edit(user0)
                msg = "🔸 تم حظر المستخدم {} ⚙️👼".format("["+cc[1]+"](tg://user?id="+cc[1]+")")
            else:
                msg = "🔸* لم يتم إيجاد المستخدم هذا بالبوت *⚙️"
            bot.send_message(chat_id=message.chat.id,text=msg, parse_mode="Markdown")
    
    
    elif cmd.startswith("/unban") and dev_id == str(message.from_user.id):
        cc = cmd.split(" ")
        if len(cc) == 2:
            user0 = None
            for u in users:
                if int(u["uid"]) == int(cc[1]):
                    user0 = u
                    break
            if user0:
                user0["ban"] = 0
                usersdb.edit(user0)
                msg = "🔸 تم الغاء حظر المستخدم {} ⚙️👼".format("["+cc[1]+"](tg://user?id="+cc[1]+")")
            else:
                msg = "🔸* لم يتم إيجاد المستخدم هذا بالبوت *⚙️"
            bot.send_message(chat_id=message.chat.id,text=msg, parse_mode="Markdown")
    
    
    
    elif cmd.startswith("/points") and dev_id == str(message.from_user.id):
        cc = cmd.split(" ")
        if len(cc) == 3:
            user0 = None
            for u in users:
                if int(u["uid"]) == int(cc[1]):
                    user0 = u
                    break
            if user0:
                user0["points"] += int(cc[2])
                usersdb.edit(user0)
                msg = "🔸 تم تعديل نقط {} و أصبحت {} نقطة بعد إضافة أو خصم {} نقطة ⚙️👼".format("["+cc[1]+"](tg://user?id="+cc[1]+")", user0["points"], cc[2])
            else:
                msg = "🔸* لم يتم إيجاد المستخدم هذا بالبوت *⚙️"
            bot.send_message(chat_id=message.chat.id,text=msg, parse_mode="Markdown")
            bot.send_message(chat_id=cc[1],text=msg, parse_mode="Markdown")
    
    
    
    elif cmd.startswith("/update") and dev_id == str(message.from_user.id):
        id = bot.send_message(chat_id=message.from_user.id,text="جارى تنفيذ طلبك ...", parse_mode="Markdown").id
        os.system("python3.9 main.py")
        bot.edit_message_text(chat_id=message.from_user.id,message_id=id,text="تم إكمال التحديث بنجاح")
        
        
        
        
    
    
    elif cmd.startswith("/price") and dev_id == str(message.from_user.id):
        cc = cmd.split(" ")
        if len(cc) == 3:
            price = None
            for p in prices:
                if int(p["code"]) == int(cc[1]):
                    price = p
                    break
            if price:
              if len(cc) == 3 and not cc[2] == "delete":
                price["points"] = cc[2]
                pricesdb.edit(price)
                msg = "🔸 تم تعديل {} و اصبح ب {} نقط ⚙️👼".format(cc[1], cc[2])
              elif len(cc) == 3 and cc[2] == "delete":
                pricesdb.delete(price)
                msg = "🔸 تم حذف {} ⚙️👼".format(cc[1])
            else:
                pricesdb.add({"code":cc[1],"points":cc[2]})
                msg = "🔸 تم اضافة {} بسعر {} نقط ⚙️👼".format(cc[1], cc[2])
            bot.send_message(chat_id=message.chat.id,text=msg, parse_mode="Markdown")
            bot.send_message(chat_id=cc[1],text=msg, parse_mode="Markdown")
            
    
    
    elif cmd.startswith("/gift") and dev_id == str(message.from_user.id):
        cc = cmd.split(" ")
        if len(cc) == 2:
            server["gift"] = cc[1]
            serverdb.edit(server)
            bot.send_message(chat_id=message.from_user.id,text=f"تم تعديل الهدية اليومية الى {cc[1]} نقط .", parse_mode="Markdown")
            
            
    
    else:
        pass
























bot.polling(none_stop=True)