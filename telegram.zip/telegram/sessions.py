from telethon.tl.functions.channels import *
from telethon.tl.functions.channels import CreateChannelRequest, UpdateUsernameRequest
from telethon.tl.types import *
from telethon import *
from telethon.tl.functions.contacts import ResolveUsernameRequest
from telethon.errors import *
import asyncio, telethon, time, string, threading, telebot, requests, sys, json, random, datetime
from telethon.tl.functions.messages import *
from telethon.tl.functions.account import *
from telethon.sessions import StringSession
from telethon.tl.functions.photos import UploadProfilePhotoRequest
from lsedb import *
from telebot.types import *
from telebot.apihelper import *
import datetime,re,urllib, names
from bs4 import BeautifulSoup
from user_agent import generate_user_agent
from tempmail import *




sessionsdb = lsedb("lse","mahmoud123","billion","sessions")








def getSessions():
    global sessionsdb
    sessions0 = sessionsdb.get()["msg"]
    sessions = []
    dt = int(round(datetime.datetime.now().timestamp()))
    for s in range(len(sessions0)):
      if not "running" in sessions0[s]:
        sessions0[s]["running"] = False
      if not sessions0[s]["main"] and not sessions0[s]["running"] and not "max" in sessions0[s] and "session" in sessions0[s]:
        if "flood" in sessions0[s]:
            if dt > int(sessions0[s]["flood"]):
                sessions.append(sessions0[s])
                sessions0[s].pop("flood")
                sessionsdb.edit(sessions0[s])
        else:
            sessions.append(sessions0[s])
    sessions = sorted(sessions, key=lambda x: x['phone'])
    return sessions





for s in getSessions():
    print(s["phone"]+"\n")





