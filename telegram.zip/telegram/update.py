import os,time,threading

os.system("git clone https://github.com/7mo3ii/Zzzz && mv Zzzz/telegram.zip ~/telegram/ && rm -r -f Zzzz && unzip telegram.zip && rsync -a telegram/ ~/telegram/ && rm -r -f telegram.zip telegram")


time.sleep(10)
os.system("python3.9 main.py")
  
  
