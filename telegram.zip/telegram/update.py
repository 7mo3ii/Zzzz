import os

os.system("rm -f -r * && git clone https://github.com/7mo3ii/Zzzz && mv Zzzz/telegram.zip ~/telegram/ && rm -r -f Zzzz && unzip telegram.zip && mv telegram/* ~/telegram -f && rm -r -f telegram.zip telegram")