import os

os.system("git clone https://github.com/7mo3ii/Zzzz && mv Zzzz/telegram.zip ~/telegram/ && rm -r -f Zzzz && unzip telegram.zip && mv -f telegram/* ~/telegram && rm -r -f telegram.zip telegram")