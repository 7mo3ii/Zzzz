import os

os.system("git clone https://github.com/7mo3ii/Zzzz && mv Zzzz/telegram.zip .. && rm -r -f Zzzz && unzip telegram.zip && rm -r -f telegram.zip")